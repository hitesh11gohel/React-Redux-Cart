import React from 'react'
import { Box } from "@material-ui/core";
const Footer = () => {
    return (
        <div className="bg-dark text-white py-2">
            <Box align="right" className="px-5">
                <h6 style={{color:'#F0FFFF'}}>@Epistic2021</h6>
            </Box>
        </div>
    )
}
export default Footer
