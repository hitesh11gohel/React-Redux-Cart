import axios from "axios";
import React, { useEffect, useState, memo } from "react";
import AddIcon from "@material-ui/icons/Add";
import EditIcon from "@material-ui/icons/Edit";
import RemoveIcon from "@material-ui/icons/Remove";

const Demo = () => {
  const [isLoading, setIsLoading] = useState(true);
  // const [order_no, setOrder_no] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [customer_id, setCustomer_id] = useState("");

  const [data, setData] = useState([]);

  const [customer, setCustomer] = useState([]);
  const loadCustomer = async () => {
    await axios.get("http://127.0.0.1:3333/api/customers").then((res) => {
      if (res.status === 201) {
        setIsLoading(true);
      } else {
        setCustomer(res.data.all_Customer);
        setIsLoading(false);
      }
    });
  };

  const [product, setProduct] = useState([]);
  const loadProduct = async () => {
    await axios.get("http://127.0.0.1:3333/api/products").then((res) => {
      if (res.status === 201) {
        setIsLoading(true);
      } else {
        setProduct(res.data.products);
        setIsLoading(false);
      }
    });
  };

  const [order, setOrder] = useState([]);
  const loadOrder = async () => {
    await axios.get("http://127.0.0.1:3333/api/orders").then((res) => {
      if (res.status === 201) {
        setIsLoading(true);
      } else {
        console.log("Order", order);
        setOrder(res.data.orders);
        setIsLoading(false);
      }
    });
  };

  useEffect(() => {
    loadCustomer();
    loadProduct();
    loadOrder();
  }, []);

  const message = () => {
    return (
      <div className="text-white p-3">
        <h3>Order Not Available</h3>
      </div>
    );
  };

  const [product_id, setProduct_id] = useState("");
  const [price, setPrice] = useState(0);
  const [total_amount, setTotalAmount] = useState(0);
  const [Product_name, setProduct_name] = useState("");

  const addOrder = async () => {
    setData([
      ...data,
      {
        product_no: product_id,
        Product_name: Product_name,
        quantity: quantity,
        price: price,
        total_amount: total_amount,
      },
    ]);
    loadCustomer();
    setQuantity(1);
    setPrice(0);
    setTotalAmount(0);
  };

  const addQuantity = () => {
    if (quantity === 1) {
      setQuantity(1);
    } else {
      setQuantity(quantity - 1);
    }
  };

  const handleChange = (event) => {
    setProduct_id(JSON.parse(event.target.value).product_id);
    setProduct_name(JSON.parse(event.target.value).product_name);
    setTotalAmount(JSON.parse(event.target.value).product_price);
    setPrice(JSON.parse(event.target.value).product_price);
    setQuantity(1);
  };

  useEffect(() => {
    setTotalAmount(price * quantity);
  }, [quantity]);

  return (
    <div className="h-screen pt-10 flex">
      <div className="container">
        {isLoading ? (
          message()
        ) : (
          <div
            style={{ marginTop: "50px" }}
            className="p-5 border border-secondary"
          >
            <div className="row">
              <select
                className="form-select form-select-lg"
                aria-label=".form-select-lg example"
              >
                <option defaultValue="">Customer</option>
                {customer.map((data, index) => (
                  <option
                    value={data.customer_id}
                    key={index}
                    onClick={() => {
                      setCustomer_id(data.customer_id);
                    }}
                  >
                    {data.customer_name}
                  </option>
                ))}
              </select>

              {/* <div className="row"> */}
              <div className="col-6 my-3">
                <select
                  className="form-select form-select-lg"
                  defaultValue=""
                  onChange={handleChange}
                  aria-label=".form-select-lg example"
                >
                  <option defaultValue="">Product</option>
                  {product.map((data, index) => (
                    <option value={JSON.stringify(data)} key={index}>
                      {data.product_name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-6">
                <div className="flex p-3">
                  <div
                    className="w-1/5 rounded-l-md border-1 text-center p-2.5 bg-white"
                    onClick={() => addQuantity()}
                  >
                    <RemoveIcon />
                  </div>
                  <div className="w-1/5 border-1 text-center p-2.5 bg-white">
                    {quantity}
                  </div>
                  <div
                    className="w-1/5 rounded-r-md border-1 p-2.5 bg-white text-center"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <AddIcon />
                  </div>
                </div>
              </div>
              {/* </div> */}

              <div className="text-dark pb-3">
                Product Price : {price}.00
                <br></br>
                Total Amount : {total_amount}.00
              </div>
            </div>
            <button
              type="button"
              className="btn btn-primary"
              onClick={addOrder}
            >
              <AddIcon /> Add Product
            </button>
          </div>
        )}

        <div className="my-5 p-3 border border-secondary">
          <div className="table-responsive">
          <h3 className='text-center'>Total Products</h3>

            <table className="table">
              <thead className="table-dark">
                <tr>
                  <td>Product No</td>
                  <td>Quantity</td>
                  <td>Price</td>
                  <td>Total Price</td>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody className="table-light">
                {data.map((data, index) => (
                  <tr key={index} className="text-dark">
                    <td>
                      <div>Product ID: {data.product_id}</div>
                      <div>Product Name: {data.Product_name}</div>
                    </td>
                    <td>{data.quantity}</td>
                    <td>{data.price}</td>
                    <td>{data.total_amount}</td>
                    <td>
                      <EditIcon className="text-blue-500" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex justify-content-end">
          <button type="button" className="btn btn-primary" onClick={addOrder}>
            <AddIcon /> Add Order
          </button>
        </div>
      </div>
    </div>
  );
};

export default memo(Demo);
