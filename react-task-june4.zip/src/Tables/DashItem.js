import React from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import EditIcon from "@material-ui/icons/Edit";

const DashItem = () => {
  const [data, setData] = React.useState([]);
  let history = useHistory();

  const getOrders = async () => {
    const result = await axios.get("http://127.0.0.1:3333/api/items");
    console.log(result.data);
    setData(result.data.result);
  };

  React.useEffect(() => {
    getOrders();
  }, []);

  const updateOrder = async (id) => {
    history.push(`/orders/edit/${id}`);
  };

  return (
    <div style={{ paddingTop: "5rem" }}>
      <button
        className="btn btn-primary float-end px-3"
        onClick={() => history.push("/item/add")}
        style={{ margin: "10px 65px" }}
      >
        + Create New
      </button>
      <div className="container ... flex">
        <table className="table table-bordered table-fixed">
          <thead className="table-dark">
            <tr>
              <th scope="col" width="10">
                #
              </th>
              <th scope="col" width="20">
                Item No
              </th>
              <th scope="col" width="30">
                Order no
              </th>
              <th scope="col" width="30">
                Product Id
              </th>
              <th scope="col" width="20">
                Item Price
              </th>
              <th scope="col" width="20">
                Quantity
              </th>
              <th scope="col" width="20">
                Total Amount
              </th>
              <th scope="col" width="20" className="text-center">
                Action
              </th>
            </tr>
          </thead>
          {data.map((item, i) => (
            <tbody key={i}>
              <tr>
                <th scope="row">{i + 1}</th>
                <td>{item.item_no}</td>
                <td>{item.order_no}</td>
                <td>{item.product_id}</td>
                <td>{item.price_per_item}</td>
                <td>{item.quantity}</td>
                <td>{item.amount}.00</td>
                <td className="text-center">
                  <button
                    className="px-3 mx-2 btn btn-success"
                    // onClick={() => updateOrder(item.order_no)}
                  >
                    <EditIcon color="inherit" />
                  </button>
                </td>
              </tr>
            </tbody>
          ))}
        </table>
      </div>
    </div>
  );
};

export default DashItem;
