import axios from "axios";
import React, { useEffect, useState, memo } from "react";
import { useHistory } from "react-router-dom";
import AddIcon from "@material-ui/icons/Add";
import RemoveIcon from "@material-ui/icons/Remove";

const Demo = () => {
  const history = useHistory();
  const [isLoading, setIsLoading] = useState(true);
  const [customer, setCustomer] = useState([]);
  const [product, setProduct] = useState([]);
  const [order_no, setOrder_no] = useState();
  const [quantity, setQuanity] = useState(1);
  const [price, setprice] = useState(0);
  const [total_amount, settotalAmount] = useState(0);
  const [customer_id, setCustomer_id] = useState("");
  const [product_id, setProduct_id] = useState("");
  const [Product_name, setProduct_name] = useState();
  const [order, setOrder] = useState([]);

  const [data, setData] = useState([]);

  const loadCustomer = async () => {
    await axios.get("http://127.0.0.1:3333/getcustomer").then((res) => {
      if (res.status === 201) {
        setIsLoading(true);
      } else {
        setCustomer(res.data);
        setIsLoading(false);
      }
    });
  };

  const loadProduct = async () => {
    await axios.get("http://127.0.0.1:3333/getproduct").then((res) => {
      debugger;
      if (res.status === 201) {
        setIsLoading(true);
      } else {
        setProduct(res.data.product);
        setIsLoading(false);
      }
    });
  };

  const loadOrder = async () => {
    await axios.get("http://127.0.0.1:3333/getorder").then((res) => {
      if (res.status === 201) {
        setIsLoading(true);
      } else {
        setOrder(res.data.order);
        setIsLoading(false);
      }
    });
  };
  useEffect(() => {
    loadCustomer();
    loadProduct();
    loadOrder();
  }, []);
  const message = () => {
    return (
      <div className="text-white">
        No order place plz contact to admin..........
      </div>
    );
  };

  const addorder = async () => {
    setData([
      ...data,
      {
        product_no: product_id,
        Product_name: Product_name,
        quantity: quantity,
        price: price,
        total_amount: total_amount,
      },
    ]);
    loadCustomer();
    setQuanity(1);
    setprice(0);
    settotalAmount(0);
    console.log();
  };
  const addQuamity = () => {
    if (quantity === 1) {
      setQuanity(1);
    } else {
      setQuanity(quantity - 1);
    }
  };
  const handleChange = (event) => {
    debugger;

    setProduct_id(JSON.parse(event.target.value).product_id);
    setProduct_name(JSON.parse(event.target.value).product_name);
    settotalAmount(JSON.parse(event.target.value).product_price);
    setprice(JSON.parse(event.target.value).product_price);
    setQuanity(1);
  };

  useEffect(() => {
    settotalAmount(price * quantity);
  }, [quantity]);

  return (
    <div className="h-screen pt-10 flex bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 ...">
      <div className="container">
        {isLoading ? (
          message()
        ) : (
          <div>
            <div className="row">
              <select
                className="form-select form-select-lg mb-3"
                aria-label=".form-select-lg example"
              >
                <option value="" selected disabled>
                  Customer
                </option>
                {customer.map((data, index) => (
                  <option
                    value={data.customer_id}
                    key={index}
                    onClick={() => {
                      setCustomer_id(data.customer_id);
                    }}
                  >
                    {data.customer_name}
                  </option>
                ))}
              </select>
              <div className="row">
                <div className="col-4">
                  <select
                    className="form-select form-select-lg mb-3"
                    defaultValue=""
                    onChange={handleChange}
                    aria-label=".form-select-lg example"
                  >
                    <option defaultValue="">Product</option>
                    {product.map((data, index) => (
                      <option value={JSON.stringify(data)} key={index}>
                        {data.product_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-4">
                  <div className="flex mb-3">
                    <div
                      className="w-1/5 rounded-l-md border-1 text-center p-2 bg-white"
                      onClick={() => addQuamity()}
                    >
                      <RemoveIcon />
                    </div>
                    <div className="w-1/5 border-1 text-center p-2 bg-white">
                      {quantity}
                    </div>
                    <div
                      className="w-1/5 rounded-r-md border-1 p-2 bg-white text-center"
                      onClick={() => setQuanity(quantity + 1)}
                    >
                      <AddIcon />
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-white pb-3">
                Product Price : {price}.00
                <br></br>
                Total Amount : {total_amount}.00
              </div>
            </div>
            <button
              type="button"
              className="btn btn-primary"
              onClick={addorder}
            >
              <AddIcon /> Add Product
            </button>
          </div>
        )}
        <div className="table-responsive">
          <table className="table">
            <thead className="text-white">
              <tr>
                <td>Product No</td>
                <td>Quantity</td>
                <td>Price</td>
                <td>Total Price</td>
                <td>Action</td>
              </tr>
            </thead>
            <tbody className="text-dark">
              {data.map((data, index) => (
                <tr key={index} className="text-dark">
                  <td>
                    Product ID: {data.product_id}
                    <div>Product Name: {data.Product_name}</div>
                  </td>
                  <td>{data.quantity}</td>
                  <td>{data.price}</td>
                  <td>{data.total_amount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex justify-content-end">
          <button type="button" className="btn btn-primary" onClick={addorder}>
            <AddIcon /> Add Order
          </button>
        </div>
      </div>
    </div>
  );
};

export default memo(Demo);
