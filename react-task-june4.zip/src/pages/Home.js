import React from "react";
const Home = () => {
  return (
    <div className="h-screen flex">
      <div className="m-auto flex flex-center">
        <h1 className="text-center text-5xl font-bold">Welcome to Epistic Technologies</h1>
      </div>
    </div>
  );
};

export default Home;
